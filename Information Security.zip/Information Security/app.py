import random

from flask import request, render_template, Flask, flash, redirect, url_for, jsonify

app = Flask(__name__)


# 随机生成一个素数
def get_prime():
    import random
    while True:
        prime = random.randrange(10, 5000)
        if is_prime(prime):
            return prime


# 判断素数
def is_prime(n):
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


def gcd(a, b):
    r = a % b
    while (r != 0):
        a = b
        b = r
        r = a % b
    return b


def euler(a):
    count = 0
    for i in range(1, a):
        if gcd(a, i) == 1:
            count += 1
    return count


def order(a, n, b):
    p = 1
    while (p <= n and (b ** p % a != 1)):
        p += 1
    if p <= n:
        return p
    else:
        return -1


# 求原根
def primitive_root(a):
    n = euler(a)
    prim = []
    for b in range(2, a):
        if order(a, n, b) == n:
            prim.append(b)
        if len(prim) >= 5:
            break
    return prim


def get_priviate_key():
    return random.randint(1, 5)


def get_key_generate(A, K, Q):
    return (A ** K) % Q


def get_final_key(Y, K, Q):
    return (Y ** K) % Q


@app.route('/', methods=["GET", "POST"])
def index():
    return render_template('show.html')


@app.route('/getPrime')
def getPrime():
    prime = get_prime()
    return jsonify({'data': str(prime)})


@app.route('/getPrimitiveRoot')
def get_root():
    if request.method == "GET":
        number = request.args.get("number")
        # 判断number是不是数字
        if not number.isdigit():
            return jsonify({'data': None})
        else:
            root_list = primitive_root(int(number))
            root = root_list[-1]
            return jsonify({'data': int(root)})


@app.route('/getPrivateKey')
def get_key():
    key1 = get_priviate_key()
    key2 = get_priviate_key()
    return jsonify({'Key1': int(key1), 'Key2': int(key2)})


@app.route('/getKeyGenerate')
def get_Key_Generate():
    if request.method == "GET":
        print("111")
        A = request.args.get("A")
        Q = request.args.get("Q")
        KA = request.args.get("KA")
        KB = request.args.get("KB")
        if not A.isdigit() or not Q.isdigit() or not KA.isdigit() or not KB.isdigit():
            return jsonify({'data': None})
        YA = get_key_generate(int(A), int(KA), int(Q))
        YB = get_key_generate(int(A), int(KB), int(Q))
        return jsonify({'YA': int(YA), 'YB': int(YB), "data": 1})


@app.route('/getFinalKey')
def get_Final_Key():
    if request.method == "GET":
        YA = request.args.get("YA")
        YB = request.args.get("YB")
        KA = request.args.get("KA")
        KB = request.args.get("KB")
        P = request.args.get("P")
        if not YA.isdigit() or not YB.isdigit() or not KB.isdigit():
            return jsonify({'data': None})
        else:
            final_key_1 = get_final_key(int(YB), int(KA), int(P))
            final_key_2 = get_final_key(int(YA), int(KB), int(P))
            return jsonify({'key1': int(final_key_1), 'key2': int(final_key_2), 'data': 1})


if __name__ == '__main__':
    app.run()
    # a=get_prime()
    # print(a)
    # b=get_primary_root(a)
    # print(b)
    # print(get_priviate_key())
