function get_Prime(){
    $.ajax({
      url: "/getPrime",
      success: function (data) {
        prime = data.data;
        item = document.getElementById("p");
        item.value = prime;
      },
      error: function (data) {
        alert("get_Prime() error");
      }
    });
  }
  function get_PrimitiveRoot(){
    item=document.getElementById("p");
    $.ajax({
      url: "/getPrimitiveRoot",
      data: {"number": item.value},
      success: function (data) {
        primitiveRoot = data.data;
        if (primitiveRoot==null) {
          alert("Please generate a prime number first!");
        }
        // 判断primitiveRoot是否整数
        if (primitiveRoot % 1 === 0) {
          item = document.getElementById("a");
          item.value = primitiveRoot;
        }
      },
      error: function (data) {
        alert("get_PrimitiveRoot() error");
      }
    });
  }
  function get_PriviateKey(){
    $.ajax({
      url: "/getPrivateKey",
      success: function (data) {
        item_p=document.getElementById("p");
        item_a=document.getElementById("a");
        p=item_p.value;
        a=item_a.value;
        //判断p和a是否为空
        if (p=="" || a=="") {
          alert("Please generate a prime number and a primitive root first!");
        }
        else {
          KA = data.Key1;
          KB = data.Key2;
          item1 = document.getElementById("xa");
          item1.innerHTML = KA;
          item2 = document.getElementById("xb");
          item2.innerHTML = KB;
          item3 = document.getElementById("xc");
          item3.innerHTML ="Q="+p + ", A="+ a;
        }
      },
      error: function (data) {
        alert("get_PriviateKey() error");
      }
    });
  }
  function get_Key_Generate(){
    A=document.getElementById("a").value;
        Q=document.getElementById("p").value;
        KA=document.getElementById("xa").innerHTML;
        KB=document.getElementById("xb").innerHTML;
    $.ajax({
      url: "/getKeyGenerate",
      data: {"A":A,"Q":Q,"KA":KA,"KB":KB},
      success: function (data) {
        data_ = data.data;
        if (data_==null) {
          alert("Please do the previous operation first.");
        }
        else {
          item1 = document.getElementById("y1a");
          item1.innerHTML = data.YA;
          item2 = document.getElementById("y1b");
          item2.innerHTML = data.YB;
          item3 = document.getElementById("y1c");
          item3.innerHTML = "YA="+data.YA + ", YB="+ data.YB;
        }
      },
      error: function (data) {
        alert("get_Key_Generate() error");
      }
    });
  }
    function get_Key_Exchange(){
    A=document.getElementById("a").value;
    Q=document.getElementById("p").value;
    YA=document.getElementById("y1a").innerHTML;
    YB=document.getElementById("y1b").innerHTML;
    item1=document.getElementById("y2a");
    item2=document.getElementById("y2b");
    item3=document.getElementById("y2c");
    item1.innerHTML=YB;
    item2.innerHTML=YA;
    item3.innerHTML="A="+A+", Q="+Q+", YA="+YA + ", YB="+ YB;
  }
    function get_Final_Key(){
        YA=document.getElementById("y1a").innerHTML;
        YB=document.getElementById("y1b").innerHTML;
        KA=document.getElementById("xa").innerHTML;
        KB=document.getElementById("xb").innerHTML;
        P=document.getElementById("p").value;
    $.ajax({
      url: "/getFinalKey",
      data: {"YA":YA,"YB":YB,"KA":KA,"KB":KB,"P":P},
      success: function (data) {
        data_ = data.data;
        if (data_==null) {
          alert("Please do the previous operation first.");
        }
        else {
          item1 = document.getElementById("keya");
          item1.innerHTML = data.key1;
          item2 = document.getElementById("keyb");
          item2.innerHTML = data.key2;
          item3 = document.getElementById("keyc");
          item3.innerHTML = "I can't get the final key!"
        }
      },
      error: function (data) {
        alert("get_Final_Key() error");
      }
    });
  }
